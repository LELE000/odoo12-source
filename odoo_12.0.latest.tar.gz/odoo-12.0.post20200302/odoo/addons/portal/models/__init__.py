# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_http
from . import mail_thread
from . import mail_message
from . import portal_mixin
from . import res_partner
