# -*- coding: utf-8 -*-
{
    'name': 'test mimetypes-guessing',
    'version': '0.1',
    'category': 'Tests',
    'description': """A module to generate exceptions.""",
}
